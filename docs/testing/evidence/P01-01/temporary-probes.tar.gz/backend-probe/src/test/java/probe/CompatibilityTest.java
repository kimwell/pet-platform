package probe;
import cn.dev33.satoken.SaManager;
import cn.dev33.satoken.config.SaTokenConfig;
import cn.dev33.satoken.dao.SaTokenDaoDefaultImpl;
import cn.dev33.satoken.stp.StpLogic;
import cn.dev33.satoken.dao.SaTokenDao;
import cn.hutool.core.util.StrUtil;
import cn.binarywang.wx.miniapp.api.impl.WxMaServiceImpl;
import com.github.binarywang.wxpay.service.impl.WxPayServiceImpl;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.testcontainers.postgresql.PostgreSQLContainer;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
@SpringBootTest(classes = CompatibilityTest.ProbeApp.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
class CompatibilityTest {
  @SpringBootConfiguration
  @EnableAutoConfiguration(excludeName = {
    "org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration",
    "org.springframework.boot.hibernate.autoconfigure.HibernateJpaAutoConfiguration",
    "org.springframework.boot.flyway.autoconfigure.FlywayAutoConfiguration"
  })
  static class ProbeApp { @Bean ProbeController probeController() { return new ProbeController(); } }
  @RestController
  static class ProbeController { @GetMapping("/compatibility") String probe() { return "兼容性验证"; } }
  @Autowired WebApplicationContext context;
  @Test void springBootSaTokenAndOpenApiRunTogether() throws Exception {
    assertNotNull(context.getBean(SaTokenConfig.class));
    assertNotNull(context.getBean(SaTokenDao.class));
    var mvc = MockMvcBuilders.webAppContextSetup(context).build();
    mvc.perform(get("/compatibility")).andExpect(status().isOk());
    String json = mvc.perform(get("/v3/api-docs")).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    assertTrue(json.contains("/compatibility")); assertTrue(json.contains("openapi"));
  }
  @Test void independentAccountTypesDoNotShareSessions() {
    // 仅检查 Sa-Token 机制；本探针使用内存 DAO，不作为 Redis 会话验收。
    var previous = SaManager.getSaTokenDao();
    try {
      SaManager.setSaTokenDao(new SaTokenDaoDefaultImpl());
      var employee = new StpLogic("probe-employee"); var customer = new StpLogic("probe-customer");
      String token = employee.createLoginSession("probe-subject");
      assertEquals("probe-subject", employee.getLoginIdByToken(token));
      assertNull(customer.getLoginIdByToken(token)); employee.logoutByTokenValue(token);
    } finally { SaManager.setSaTokenDao(previous); }
  }
  @Test void optionalLibrariesLoadWithoutExternalServices() {
    assertDoesNotThrow(WxMaServiceImpl::new); assertDoesNotThrow(WxPayServiceImpl::new);
    assertNotNull(Flyway.configure().load()); assertTrue(StrUtil.isNotBlank("probe"));
    // 不启动容器，只检查 Testcontainers 2 的 API 与 PostgreSQL 镜像配置兼容。
    try (var container = new PostgreSQLContainer("postgres:17.11-bookworm")) { assertNotNull(container); }
  }
}
