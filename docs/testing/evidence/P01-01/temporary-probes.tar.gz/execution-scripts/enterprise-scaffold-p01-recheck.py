from pathlib import Path
import json,os,subprocess,time,sys
root=Path(Path('/tmp/enterprise-scaffold-p01-current-path.txt').read_text());ev=root/'evidence';paths=json.loads((root/'tool-paths.json').read_text());env=os.environ.copy();env['JAVA_HOME']=paths['java_home'];env['MAVEN_USER_HOME']=str(root/'maven-user-home');env['PATH']=str(Path(paths['node']).parent)+':'+paths['java_home']+'/bin:'+env['PATH'];env['PNPM_HOME']=str(root/'pnpm-home')
records=json.loads((ev/('rechecks-'+sys.argv[1]+'-r2.json')).read_text()) if (ev/('rechecks-'+sys.argv[1]+'-r2.json')).exists() else []
def run(name,args,cwd,timeout=900):
 name = name + '-r2' if sys.argv[1] in ['front','ci'] else name
 start=time.time();log=ev/(name+'.log')
 with log.open('w') as f:
  try:r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout);code=r.returncode;status='PASS' if code==0 else 'FAIL'
  except Exception as e:f.write(str(e));code=None;status='NOT_EXECUTED'
 row={'id':name,'cwd':str(cwd),'command':args,'exit_code':code,'result':status,'seconds':round(time.time()-start,2),'log':log.name};records.append(row);(ev/('rechecks-'+sys.argv[1]+'-r2.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(row),flush=True);return code
pm=[paths['node'],paths['pnpm'],'--config.store-dir='+str(root/'pnpm-store')];front=root/'frontend-probe';backend=root/'backend-probe';base=['-B','-ntp','-s',str(root/'settings.xml'),'-gs',str(root/'settings.xml'),f'-Dmaven.repo.local={root}/m2']
if sys.argv[1]=='front':
 f=front/'package.json';d=json.loads(f.read_text());d['devDependencies'].pop('miniprogram-ci',None);f.write_text(json.dumps(d,indent=2));v=json.loads((root/'research/selected-npm.json').read_text());v['miniprogram-ci']='2.1.48';(root/'research/selected-npm.json').write_text(json.dumps(v,indent=2))
 if run('frontend-install-fixed',pm+['install','--reporter=append-only'],front)==0:
  for name,args in [('frontend-lock-replay',pm+['install','--frozen-lockfile','--reporter=append-only']),('web-types',pm+['exec','tsc','-p','web/tsconfig.json']),('web-build',pm+['--dir','web','exec','vite','build']),('web-runtime',pm+['exec','vitest','run','web/src/compatibility.test.tsx','--environment','node']),('frontend-lint',pm+['exec','eslint','web/src','mini/src','--max-warnings=0']),('mini-types',pm+['exec','tsc','-p','mini/tsconfig.json']),('openapi-types',pm+['exec','openapi-typescript','contract.json','-o','contract.generated.ts']),('openapi-types-compile',pm+['exec','tsc','--noEmit','--strict','--skipLibCheck','--target','ES2022','--moduleResolution','bundler','--module','ESNext','contract.generated.ts']),('frontend-direct-tree',pm+['list','-r','--depth','0','--json'])]:run(name,args,front)
elif sys.argv[1]=='ci':
 ci=root/'ci-probe';ci.mkdir(exist_ok=True);(ci/'.npmrc').write_text('registry=https://registry.npmjs.org\nauto-install-peers=true\nstrict-peer-dependencies=true\ncache-dir='+str(root/'ci-cache')+'\n')
 run('mini-npm-pack-isolated',pm+['dlx','miniprogram-ci@2.1.48','pack-npm-manually','--pack-npm-manually-package-json-path',str(front/'mini/package.json'),'--pack-npm-manually-miniprogram-npm-dist-dir',str(front/'mini')],ci)
elif sys.argv[1]=='backend':run('backend-tests',['./mvnw',*base,'test'],backend)
