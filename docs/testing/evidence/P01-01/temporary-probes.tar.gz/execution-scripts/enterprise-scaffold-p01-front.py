from pathlib import Path
import json,subprocess,os,time
root=Path(Path('/tmp/enterprise-scaffold-p01-current-path.txt').read_text());front=root/'frontend-probe';ev=root/'evidence';p=root/'research';v=json.loads((p/'selected-npm.json').read_text());v.update({'eslint':'10.12.0','@eslint/js':'10.0.1','eslint-plugin-react-refresh':'0.5.7'});(p/'selected-npm.json').write_text(json.dumps(v,indent=2))
paths=json.loads((root/'tool-paths.json').read_text());node=paths['node'];pnpm=paths['pnpm'];env=os.environ.copy();env['PATH']=str(Path(node).parent)+':'+env['PATH']
front.mkdir(exist_ok=True)
for sub in ['web/src','mini/src']:(front/sub).mkdir(parents=True,exist_ok=True)
(front/'pnpm-workspace.yaml').write_text('packages:\n  - web\n  - mini\n')
(front/'.npmrc').write_text('registry=https://registry.npmjs.org\nstrict-peer-dependencies=true\nauto-install-peers=false\nsave-exact=true\n')
rootdev=['typescript','@types/node','eslint','@eslint/js','typescript-eslint','eslint-plugin-react-hooks','eslint-plugin-react-refresh','vitest','openapi-typescript','miniprogram-ci']
(front/'package.json').write_text(json.dumps({'name':'compatibility-probe','private':True,'packageManager':'pnpm@'+v['pnpm'],'devDependencies':{n:v[n] for n in rootdev}},indent=2))
webdeps=['react','react-dom','antd','@ant-design/icons','@tanstack/react-router','@tanstack/react-query','zustand'];webdev=['vite','@vitejs/plugin-react','@types/react','@types/react-dom']
(front/'web/package.json').write_text(json.dumps({'name':'web-probe','private':True,'type':'module','dependencies':{n:v[n] for n in webdeps},'devDependencies':{n:v[n] for n in webdev}},indent=2))
(front/'mini/package.json').write_text(json.dumps({'name':'mini-probe','private':True,'dependencies':{'tdesign-miniprogram':v['tdesign-miniprogram']},'devDependencies':{'miniprogram-api-typings':v['miniprogram-api-typings']}},indent=2))
(front/'web/tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2022','lib':['ES2022','DOM','DOM.Iterable'],'module':'ESNext','moduleResolution':'Bundler','jsx':'react-jsx','strict':True,'noEmit':True,'skipLibCheck':False,'esModuleInterop':True,'types':['node','vite/client']},'include':['src','vite.config.ts']},indent=2))
(front/'web/vite.config.ts').write_text("import { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\nexport default defineConfig({ plugins: [react()] });\n")
(front/'web/index.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><title>兼容性探针</title></head><body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body></html>')
(front/'web/src/main.tsx').write_text('''import { createRoot } from 'react-dom/client';
import { Button, ConfigProvider, Form, Input } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { QueryClient, QueryClientProvider, useQuery } from '@tanstack/react-query';
import { createRootRoute, createRoute, createRouter, RouterProvider } from '@tanstack/react-router';
import { create } from 'zustand';
// 仅验证框架 API 与类型组合，无业务数据和真实请求。
const useProbe = create<{ ready: boolean }>(() => ({ ready: true }));
function Probe() {
  const ready = useProbe(s => s.ready);
  useQuery({ queryKey: ['compatibility'], queryFn: async () => (await fetch('/compatibility')).text(), enabled: false });
  return <Form<{ value: string }>><Form.Item name="value"><Input /></Form.Item><Button disabled={!ready} icon={<CheckOutlined />}>兼容性验证</Button></Form>;
}
const rootRoute = createRootRoute();
const route = createRoute({ getParentRoute: () => rootRoute, path: '/', component: Probe });
const router = createRouter({ routeTree: rootRoute.addChildren([route]) });
declare module '@tanstack/react-router' { interface Register { router: typeof router } }
createRoot(document.getElementById('root')!).render(<ConfigProvider><QueryClientProvider client={new QueryClient()}><RouterProvider router={router} /></QueryClientProvider></ConfigProvider>);
''')
(front/'web/src/compatibility.test.tsx').write_text('''import { expect, test } from 'vitest';
import { renderToString } from 'react-dom/server';
import { Button, Form, Input } from 'antd';
import { QueryClient } from '@tanstack/react-query';
import { createRootRoute, createRoute, createRouter, createMemoryHistory } from '@tanstack/react-router';
import { createStore } from 'zustand/vanilla';
test('React 与 Ant Design Form 在同一运行时渲染', () => {
  const html = renderToString(<Form><Form.Item name="value"><Input /></Form.Item><Button>兼容性验证</Button></Form>);
  expect(html).toContain('兼容性验证'); expect(html).toContain('ant-form');
});
test('Router、Query 与 Zustand 的实际 API 可以运行', async () => {
  const root = createRootRoute(); const route = createRoute({ getParentRoute: () => root, path: '/' });
  const router = createRouter({ routeTree: root.addChildren([route]), history: createMemoryHistory({ initialEntries: ['/'] }) });
  await router.load(); expect(router.state.location.pathname).toBe('/');
  const query = new QueryClient(); expect(await query.fetchQuery({ queryKey: ['probe'], queryFn: () => 'ready' })).toBe('ready'); query.clear();
  const store = createStore<{ ready: boolean }>(() => ({ ready: false })); store.setState({ ready: true }); expect(store.getState().ready).toBe(true);
});
''')
(front/'mini/tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2020','lib':['ES2020'],'module':'CommonJS','moduleResolution':'Node','strict':True,'noEmit':True,'skipLibCheck':False,'types':['miniprogram-api-typings']},'include':['src']},indent=2))
(front/'mini/src/probe.ts').write_text('''import type { TdButtonProps } from 'tdesign-miniprogram/button/type';
// 只检查原生小程序类型，不注册业务页面、不创建微信配置。
export const props: TdButtonProps = { theme: 'primary' };
export function requestTypeProbe() {
  return wx.request<{ success: boolean }>({ url: 'https://example.invalid/compatibility', success: response => { const ok: boolean = response.data.success; return ok; } });
}
''')
(front/'eslint.config.mjs').write_text('''import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import hooks from 'eslint-plugin-react-hooks';
import refresh from 'eslint-plugin-react-refresh';
export default [ { ignores: ['**/dist/**', '**/miniprogram_npm/**', '**/node_modules/**'] }, js.configs.recommended, ...tseslint.configs.recommended, {
  files: ['**/*.ts', '**/*.tsx'], languageOptions: { globals: { document: 'readonly', fetch: 'readonly', wx: 'readonly' } },
  plugins: { 'react-hooks': hooks, 'react-refresh': refresh }, rules: { ...hooks.configs.recommended.rules, 'react-refresh/only-export-components': ['warn', { allowConstantExport: true }] }
} ];
''')
(front/'mini-pack.cjs').write_text('''const ci = require('miniprogram-ci');
const path = require('node:path');
ci.packNpmManually({ packageJsonPath: path.join(__dirname, 'mini/package.json'), miniprogramNpmDistDir: path.join(__dirname, 'mini') }).then(result => { console.log(JSON.stringify(result)); }).catch(error => { console.error(error); process.exitCode = 1; });
''')
(front/'contract.json').write_text(json.dumps({'openapi':'3.0.3','info':{'title':'兼容性探针','version':'0.0.0'},'paths':{'/compatibility':{'get':{'responses':{'200':{'description':'类型探针','content':{'application/json':{'schema':{'type':'object','properties':{'success':{'type':'boolean'}}}}}}}}}}},ensure_ascii=False,indent=2))
records=[]
def run(name,args,cwd=front,timeout=900):
 log=ev/(name+'.log');start=time.time()
 with log.open('w') as f:
  try:r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout);code=r.returncode;status='PASS' if code==0 else 'FAIL'
  except Exception as e:f.write(str(e));code=None;status='NOT_EXECUTED'
 row={'id':name,'cwd':str(cwd),'command':args,'exit_code':code,'result':status,'seconds':round(time.time()-start,2),'log':log.name};records.append(row);(ev/'frontend-commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(row),flush=True);return code
pm=[node,pnpm,'--store-dir',str(root/'pnpm-store')]
if run('frontend-install',pm+['install','--reporter=append-only'])==0:
 run('frontend-lock-replay',pm+['install','--frozen-lockfile','--reporter=append-only'])
 run('web-types',pm+['exec','tsc','-p','web/tsconfig.json'])
 run('web-build',pm+['--dir','web','exec','vite','build'])
 run('web-runtime',pm+['exec','vitest','run','web/src/compatibility.test.tsx','--environment','node'])
 run('frontend-lint',pm+['exec','eslint','web/src','mini/src','--max-warnings=0'])
 run('mini-types',pm+['exec','tsc','-p','mini/tsconfig.json'])
 run('mini-npm-pack',[node,str(front/'mini-pack.cjs')])
 run('openapi-types',pm+['exec','openapi-typescript','contract.json','-o','contract.generated.ts'])
 run('openapi-types-compile',pm+['exec','tsc','--noEmit','--strict','--skipLibCheck','--target','ES2022','--moduleResolution','bundler','--module','ESNext','contract.generated.ts'])
 run('frontend-direct-tree',pm+['list','-r','--depth','0','--json'])
