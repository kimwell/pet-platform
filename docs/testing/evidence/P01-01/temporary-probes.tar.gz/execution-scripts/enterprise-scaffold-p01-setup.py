from pathlib import Path
import json,urllib.request,hashlib,tarfile,subprocess,os,concurrent.futures,time
root=Path(Path('/tmp/enterprise-scaffold-p01-current-path.txt').read_text());ev=root/'evidence';backend=root/'backend-probe';front=root/'frontend-probe';tools=root/'tools'
for p in [backend,front,tools]:p.mkdir(exist_ok=True)
settings=root/'settings.xml';settings.write_text('<settings xmlns="http://maven.apache.org/SETTINGS/1.2.0"><mirrors><mirror><id>official-central</id><mirrorOf>*</mirrorOf><url>https://repo.maven.apache.org/maven2</url></mirror></mirrors></settings>')
records=[]
def record(name,cmd,cwd,timeout=900,env=None):
 start=time.time();log=ev/(name+'.log')
 with log.open('w') as f:
  try:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env=env);code=r.returncode;status='PASS' if code==0 else 'FAIL'
  except Exception as e:f.write(str(e));code=None;status='NOT_EXECUTED'
 row={'id':name,'cwd':str(cwd),'command':cmd,'exit_code':code,'result':status,'seconds':round(time.time()-start,2),'log':log.name}
 records.append(row);(ev/'commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(row,ensure_ascii=False),flush=True);return code

def download(name,url,expected=None):
 path=tools/name
 start=time.time()
 try:
  with urllib.request.urlopen(url,timeout=90) as r,path.open('wb') as f:
   while b:=r.read(1024*1024):f.write(b)
  sha=hashlib.sha256(path.read_bytes()).hexdigest()
  if expected and sha!=expected:raise RuntimeError('checksum mismatch')
  row={'name':name,'url':url,'sha256':sha,'bytes':path.stat().st_size,'result':'PASS','seconds':round(time.time()-start,2)}
 except Exception as e:row={'name':name,'url':url,'result':'NOT_EXECUTED','reason':str(e)}
 print(json.dumps(row),flush=True);return row
nodeversion='24.21.0';nname=f'node-v{nodeversion}-darwin-arm64.tar.gz';nurl=f'https://nodejs.org/dist/v{nodeversion}/{nname}'
sha=urllib.request.urlopen(f'https://nodejs.org/dist/v{nodeversion}/SHASUMS256.txt',timeout=30).read().decode();(ev/'node-SHASUMS256.txt').write_text(sha);nsha=next(l.split()[0] for l in sha.splitlines() if l.endswith(' '+nname))
selected=json.loads((root/'research'/'selected-npm.json').read_text());pver=selected['pnpm'];pdata=json.loads((root/'research'/'npm-pnpm.json').read_text())['versions'][pver];(ev/'pnpm-package-metadata.json').write_text(json.dumps(pdata,indent=2))
jmeta=json.loads((root/'research'/'temurin2.json').read_text());jasset=next(a for a in jmeta['assets'] if 'jdk_aarch64_mac_hotspot' in a['name'] and a['name'].endswith('.tar.gz'))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 tasks=[pool.submit(download,nname,nurl,nsha),pool.submit(download,'pnpm.tgz',pdata['dist']['tarball']),pool.submit(download,jasset['name'],jasset['browser_download_url'])]
 downloads=[f.result() for f in tasks]
(ev/'downloads.json').write_text(json.dumps(downloads,indent=2))
for row in downloads:
 if row['result']=='PASS':
  dest=tools/'pnpm' if row['name']=='pnpm.tgz' else tools
  dest.mkdir(exist_ok=True)
  with tarfile.open(tools/row['name']) as t:t.extractall(dest,filter='data')
node=tools/f'node-v{nodeversion}-darwin-arm64'/'bin'/'node';pnpm=tools/'pnpm'/'package'/'bin'/'pnpm.cjs'
jdks=list(tools.glob('jdk*/Contents/Home'));jhome=jdks[0] if jdks else Path('/Users/kimwell/sdk/java/zulu-21.jdk/Contents/Home')
env=os.environ.copy();env['JAVA_HOME']=str(jhome);env['MAVEN_USER_HOME']=str(root/'maven-user-home');env['PATH']=str(node.parent)+':'+str(jhome/'bin')+':'+env['PATH']
(root/'tool-paths.json').write_text(json.dumps({'node':str(node),'pnpm':str(pnpm),'java_home':str(jhome)},indent=2))
for name,cmd in [('target-node',[str(node),'--version']),('target-pnpm',[str(node),str(pnpm),'--version']),('probe-java',[str(jhome/'bin'/'java'),'-version'])]:record(name,cmd,root,30,env)
def dep(group,artifact,version=None,scope=None):return '<dependency><groupId>'+group+'</groupId><artifactId>'+artifact+'</artifactId>'+('<version>'+version+'</version>' if version else '')+('<scope>'+scope+'</scope>' if scope else '')+'</dependency>'
deps=''.join([dep('org.springframework.boot',a) for a in ['spring-boot-starter-webmvc','spring-boot-starter-data-jpa','spring-boot-starter-data-redis','spring-boot-starter-amqp','spring-boot-starter-flyway']])+''.join([dep('cn.dev33','sa-token-spring-boot4-starter','1.46.0'),dep('cn.dev33','sa-token-redis-template','1.46.0'),dep('cn.hutool','hutool-core','5.8.47'),dep('org.springdoc','springdoc-openapi-starter-webmvc-ui','3.0.3'),dep('org.flywaydb','flyway-database-postgresql'),dep('org.postgresql','postgresql'),dep('com.github.binarywang','weixin-java-miniapp','4.8.0'),dep('com.github.binarywang','weixin-java-pay','4.8.0'),dep('org.springframework.boot','spring-boot-starter-test',scope='test'),dep('org.springframework.boot','spring-boot-starter-webmvc-test',scope='test'),dep('org.testcontainers','testcontainers-postgresql',scope='test'),dep('org.testcontainers','testcontainers-junit-jupiter',scope='test')])
(backend/'pom.xml').write_text('<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion><parent><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-parent</artifactId><version>4.0.8</version></parent><groupId>probe</groupId><artifactId>compatibility-probe</artifactId><version>0.0.0</version><properties><java.version>21</java.version></properties><dependencies>'+deps+'</dependencies></project>')
base=['-B','-ntp','-s',str(settings),'-gs',str(settings),f'-Dmaven.repo.local={root}/m2']
record('wrapper-bootstrap',['mvn',*base,'org.apache.maven.plugins:maven-wrapper-plugin:3.3.4:wrapper','-Dmaven=3.9.16','-Dtype=only-script'],backend,900,env)
if (backend/'mvnw').exists():
 record('wrapper-version',['./mvnw',*base,'--version'],backend,180,env)
 record('backend-resolve',['./mvnw',*base,'org.apache.maven.plugins:maven-dependency-plugin:3.9.0:tree','-Dverbose','-DoutputFile='+str(ev/'backend-dependency-tree.txt')],backend,900,env)
 record('backend-effective-pom',['./mvnw',*base,'help:effective-pom','-Doutput='+str(ev/'backend-effective-pom.xml')],backend,600,env)
