from pathlib import Path
root=Path('/Users/kimwell/work/enterprise-app-scaffold')
assert not root.exists(), '目标目录已出现；停止写入以避免覆盖'
root.mkdir()
files={
'AGENTS.md':'''# 企业应用工程脚手架开发规则

本规则只适用于 enterprise-app-scaffold。它是独立工程，不使用 Product Delivery OS；不得安装、调用、引入该框架，不创建 `.delivery-os`，不读取或更新其状态。本轮授权只覆盖 P01-01，不自动执行 P01-02 或 P02。

## 技术与依赖

后端采用 Java、Spring Boot、模块化单体、一个 Maven Module、Maven Wrapper、Spring Data JPA/Hibernate、PostgreSQL、Flyway、Sa-Token、范围受限的 Hutool、Spring Data Redis、Spring AMQP；RabbitMQ 和 binarywang/WxJava 小程序/支付能力按需启用。存储默认本地文件，协议使用 OpenAPI，测试使用 JUnit 和 Testcontainers。

Web 使用 React、TypeScript、Vite、Ant Design、TanStack Router、TanStack Query、Zustand、Ant Design Form 和原生 fetch。微信端使用原生微信小程序、TypeScript、tdesign-miniprogram、页面 data 和轻量会话管理；客户与员工是独立身份域，不引入额外复杂状态库。

精确版本的唯一文档事实源是 [VERSION-MATRIX](docs/development/VERSION-MATRIX.md)。直接依赖固定版本，不以 latest、^、~ 冻结基线；受 Spring Boot BOM 管理的依赖不重复指定版本，实际解析版本必须留证。全仓前端只使用 pnpm 和一份根 `pnpm-lock.yaml`。正式工程初始化属于 P02，当前不创建应用、空类或假业务目录。

不得新增微服务架构、MySQL、作为生产等价替代的 H2、MinIO、Kafka、Elasticsearch、Next.js、React Router、Redux、MobX、Taro、uni-app。发现实际兼容问题，先记录证据并给出最小调整；不得擅自更换技术体系。

## 实现和文案

业务说明、注释、错误提示和用户文案使用中文；技术名称、标识符可用英文。直接使用官方 Ant Design 和 TDesign 组件，不创建仅透传属性或重复官方 API 的无意义 Wrapper。只有承载明确业务规则、可访问性或跨端协议的封装才有价值。Ant Design Form 负责表单，Query 负责服务端数据，Zustand 仅管理少量跨页面客户端状态。

后端基础包暂定 `com.company.scaffold`，未来生成工具必须支持替换 package、项目名和工程标识。业务模块采用 api/application/domain/infrastructure；不要为分层创建无行为的空类。基础能力与项目特定业务分开；本模板不包含宠物、寄养、房间、预约、订单、优惠券、积分、具体经营统计。

## 身份和租户

采用 Sa-Token 服务端会话，不叠加自建 JWT 刷新体系。平台管理员、租户员工、客户认证空间隔离，令牌和 Cookie 名称、读取策略、会话键前缀也需要隔离。Web 默认同源安全 Cookie，配套独立 CSRF 机制；不能仅靠 SameSite 声称解决 CSRF。小程序使用 Token，跨源 Web 部署是需要单独验证的可选方案。

tenantId 只能来自经过验证的可信身份；请求中的 tenantId 不授予访问权。单租户和多租户共用隔离机制；Tenant、可选 Store、内部 Organization 不得混淆。查询、写入、批量操作、原生 SQL、附件、导出、异步任务、消息、缓存都必须隔离；无可信上下文默认拒绝。平台管理通道须显式授权和审计，不得作为隐式绕过租户限制的路径。

## 变更与验证

先读适用规则和现有实现，保持变更聚焦，不修改无关文件，不删除或覆盖其他项目成果，不修改全局 Java/Node.js/包管理器配置，不输出秘密环境变量，不生成真实账号、密码、密钥。可在明确临时目录进行必要探针。

禁止用 Mock 页面、假业务数据、文档检查或内存数据库作为真实业务验收。单元测试的技术夹具须与业务验收明确区分。后续数据库集成用真实 PostgreSQL/Testcontainers；测试覆盖租户越权的查询和写入、身份跨域、无上下文拒绝、附件与异步传播。

每项检查保留工作目录、命令、退出码、输出摘要及证据；分别记录 DOCUMENTED、RESOLVED、COMPILED、RUNTIME_VERIFIED、NOT_VERIFIED，等级不得相互代替。无法执行记 NOT_EXECUTED 和原因，不伪造 PASS。新增或修改依赖后执行受影响的编译、类型、构建或集成检查，链接和事实源保持一致。

不自动提交、推送、发布或部署；不建立逐个可逆操作都请求确认的流程，不建立审批工作流。阶段推进以当前明确任务授权为边界，P01-01 完成不等于 P01 全部完成。
''',
'README.md':'''# 企业应用工程脚手架

工程标识暂定：`enterprise-app-scaffold`。目标是提供可生成新项目的 Java 后端、React 管理后台、原生微信小程序及基础能力、模板和本地开发设施，使新项目可以直接开发业务模块和页面。

截至 2026-10-07，实际产物仅为 P01-01 文档、规则和验证证据。正式三端工程、认证、租户隔离、员工管理、附件、审计、初始化工具和代码模板均未实现。本项目完全独立，不使用 Product Delivery OS。

本轮位置由用户明确选择为 `/Users/kimwell/work/enterprise-app-scaffold`；原目录 `/Users/kimwell/work/pet-platform` 的现有 UI 成果保留。本项目尚未初始化 Git，不存在分支或提交；不会将原项目内容复制成脚手架业务。

## 阅读入口

- [项目开发规则](AGENTS.md)
- [范围与边界](docs/product/SCAFFOLD-SCOPE.md)
- [技术基线](docs/architecture/TECHNICAL-BASELINE.md)
- [精确版本与兼容依据](docs/development/VERSION-MATRIX.md)
- [规划工程结构](docs/architecture/PROJECT-STRUCTURE.md)
- [核心契约概要](docs/contracts/CORE-CONTRACTS.md)
- [P01～P12 开发路线](docs/development/ROADMAP.md)
- [工程决策记录](docs/development/DECISION-LOG.md)
- [P01-01 验证与完成条件](docs/testing/P01-01-VERIFICATION.md)

精确版本以版本矩阵为准，依赖解析以报告链接的真实输出为证。临时探针不构成完整工程验收；数据库、缓存、消息和微信真实场景的验证边界见验证报告。

下一任务暂定为 P01-02：核心架构与三端契约详细冻结。本轮不自动执行，P02 初始化须在对应任务授权后进行。
''',
'docs/product/SCAFFOLD-SCOPE.md':'''# 脚手架范围

日期：2026-10-07。定位为企业应用工程模板；当前只执行 P01-01。

## 最终范围（尚未实现）

| 部分 | 可复用能力 | 边界 |
| --- | --- | --- |
| Java 后端 | 统一协议、数据迁移、多租户与数据范围、身份权限、附件、审计、通知 | 单 Maven Module 的模块化单体，不提供项目特定业务 |
| React 管理后台 | 应用壳、会话、权限、菜单路由、通用企业页面模式、员工管理 | 直接使用官方 Ant Design；不创造第二套 UI 系统 |
| 原生微信小程序 | 原生请求、会话、页面模式、客户和员工独立认证 | 不引入跨端框架与复杂状态库 |
| 本地基础设施 | PostgreSQL、Redis、可选 RabbitMQ、文件目录和启动说明 | 容器化依赖；本地验证不代表生产部署 |
| 初始化工具 | 新项目名称、标识、package、配置替换、可选能力裁剪 | 不携带真实账号、密钥或原项目业务 |
| 模板和说明 | 后端业务模块、Web 页面、小程序页面、验收说明 | 能在全新目录生成并独立运行，P12 真实验收 |

## 明确排除

不包含宠物、寄养、房间、预约、订单、优惠券、积分、具体经营统计等行业业务。支付 SDK 属于可选技术接入，不意味着提供订单或商业支付业务。

不采用微服务架构、MySQL、生产等价 H2、MinIO、Kafka、Elasticsearch、Next.js、React Router、Redux、MobX、Taro、uni-app；不使用 Product Delivery OS，不建立审批工作流。

## 本轮边界

允许只读项目事实检查、官方版本研究、临时兼容探针，以及文档和规则文件。禁止初始化正式三端工程、提前实现用户/角色/租户、Mock 业务页面、假业务验收、提交/推送/发布/部署、覆盖原成果。

P01-01 交付开发规则、技术基线、版本矩阵、规划结构、核心契约概要、路线、决策和实际验证报告。P01-01 完成只说明具备进入 P01-02 的技术依据；不代表平台基础能力完成，也不代表 P01 全部完成。

## 可复用性验收方向

P12 在一个全新目录由初始化工具生成三端项目：名称与基础包全部替换；默认能力能用真实基础设施验证；可选 RabbitMQ/WxJava 关闭时能运行；不同项目不共享数据、身份或文件路径。详见 [路线图](../development/ROADMAP.md)。
''',
'docs/architecture/TECHNICAL-BASELINE.md':'''# 技术基线

建立日期：2026-10-07。本文件记录组合与使用规则；精确版本、来源、解析值和验证等级统一见 [版本矩阵](../development/VERSION-MATRIX.md)，当前证据见 [验证报告](../testing/P01-01-VERIFICATION.md)。

## 后端

Java 21 LTS，目标发行版 Eclipse Temurin。Spring Boot 采用 4.0 稳定维护线，与 Sa-Token Boot 4 starter、springdoc 3.0 对齐；不追逐所有组件的最新主/次版本。后端只有一个 Maven Module，按包划分模块化单体；不引入 Spring Modulith 等额外框架作为分层前提。

以 Spring Boot starter parent/BOM 统一管理 Spring Framework、Spring Data JPA、Hibernate、JDBC 驱动、Flyway、Spring Data Redis、Spring AMQP、JUnit 与 Testcontainers 的解析版本。正式工程使用 Maven Wrapper `only-script` 方式，固定 Maven 分发地址及 SHA-256；开发者和 CI 无须预装全局 Maven。当前系统 Maven 仅用于临时探针的 Wrapper 引导，不成为正式运行要求。

PostgreSQL 是唯一数据库。Flyway 管理版本迁移，显式加入 `org.flywaydb:flyway-database-postgresql`，禁止依赖 Hibernate 自动修改生产结构；后续采用 schema 验证。真实 SQL、事务、锁和隔离以 PostgreSQL 集成测试验证。

Sa-Token 维护服务端会话。Redis 作为跨实例会话/缓存存储，采用与 starter 相同版本的 `sa-token-redis-template`；内存 DAO 仅可用于隔离技术单元测试，不作为会话上线或持久性验收。Boot 4 默认 Jackson 3，WxJava 可能携带 Jackson 2/Gson，按不同包名并存核查，不盲目把 SDK 强制迁移到 Jackson 3。

Hutool 仅引入 `hutool-core`，允许必要字符串/集合等工具；不得替代 JPA、Spring 配置、JSON 协议、HTTP 请求、认证、加密、文件权限和租户控制。新增 Hutool 子模块须有实际需求和验证，不使用 `hutool-all`。

Spring AMQP 对接可选 RabbitMQ；默认不开启消息业务，关闭时不创建连接、监听器或依赖启动条件。WxJava 仅按需引入 `weixin-java-miniapp` / `weixin-java-pay` 原始模块，不引入其 Spring Boot starter，避免额外框架版本覆盖。当前不配置微信凭证，不实现真实微信登录/支付。

本地文件存储是默认适配器，元数据在 PostgreSQL，目录和下载均受租户授权控制；不把裸物理路径返回客户端，不引入 MinIO。OpenAPI 是接口事实源，JUnit/Testcontainers 为测试基础。

## 管理后台

React 与 React DOM 使用同一精确版本，Ant Design 6 支持 React 19，不使用 v5 React 19 补丁。Ant Design Form 处理表单，直接使用官方组件；只在有明确业务语义时进行封装。

Vite 7.3 的官方维护策略覆盖重要修复和安全补丁，React 插件使用与其兼容的 5 系列。TypeScript 固定 5.9，满足类型生成和静态检查工具 peer 要求。Node.js 24 LTS 与 pnpm 10 在临时目录运行，不改变本机的 Node.js 22 或全局 pnpm。

TanStack Router 是唯一路由；P01 探针使用代码路由，未来是否采用官方文件路由插件在 P01-02 详细冻结，新增插件必须先冻结精确版本。TanStack Query 管理服务端状态、失效和请求缓存；Zustand 仅管理少量客户端共享状态；表单数据不复制到两套状态库。请求基于 fetch，处理 HTTP 状态和统一响应，默认同源 credentials，业务错误不吞掉。

静态检查采用 ESLint 10、typescript-eslint、官方 Hooks/Refresh 插件及 `tsc`；测试采用 Vitest 4，不预装大量浏览器/覆盖率工具。真实浏览器、视觉、可访问性和端到端验收按后续任务需要增加。

## 微信小程序及共享协议

原生微信小程序、TypeScript、tdesign-miniprogram；页面 data 与轻量会话管理，不引入 Taro/uni-app。客户和员工会话域独立，原生 `wx.request` 实现请求，不把 Web fetch、DOM 或 React 类型带入小程序共享层。

`packages/api-contracts` 未来只承载 OpenAPI 生成类型与纯协议辅助类型，不运行 Cookie、fetch、wx.request 或状态管理。类型由 OpenAPI 生成，Web/小程序保留各自传输实现；禁止双向手工修改生成文件。

全仓仅使用 pnpm 和一份根锁文件，直接版本精确，CI 使用 frozen lockfile。微信 npm 构建采用官方 miniprogram-ci 的离线 `packNpmManually` 探针验证 pnpm 依赖布局；预览/上传与真机验证另行执行，当前不创建 AppID 或上传密钥。

## 维护和限制

基线冻结表示可复现，不表示永不升级。P02 执行前、P12 发布前以及官方支持窗口变化时复核受影响版本和安全更新；补丁更新需记录矩阵、决策和受影响验证，不改 BOM 来追求每行显式版本。

PostgreSQL 选择成熟 17 系列；Redis 选择 8.2 Extended 系列；RabbitMQ 选择当前社区支持的 4.3 系列。RabbitMQ 社区支持计划于 2026-11-30 结束，P10 启用前必须重新核对，不能将商业支持期限当成免费维护承诺。Redis 8 的授权选项需要随分发方式检查，技术兼容探针不作许可证法律结论。

详细认证、CSRF、租户执行位置、跨源部署、时间/金额序列化、测试分层和文件生命周期进入 P01-02，当前只冻结方向和技术组合。
''',
'docs/architecture/PROJECT-STRUCTURE.md':'''# 工程结构规划

日期：2026-10-07。以下目录是未来规划；当前实际只有根规则、README、docs 和文档证据，不创建这些正式应用或空类。

```text
enterprise-app-scaffold/
├── AGENTS.md
├── README.md
├── apps/
│   ├── backend/                 # 唯一 Maven Module，包含 mvnw/.mvn
│   ├── admin-web/               # React 管理后台
│   └── wechat-miniprogram/      # 原生微信小程序
├── packages/
│   └── api-contracts/           # OpenAPI 生成的纯协议类型
├── templates/                  # 后端/Web/小程序模板
├── scripts/                    # 初始化、契约生成和验证
├── infra/
│   └── local/                  # PostgreSQL/Redis/可选 RabbitMQ
└── docs/
```

全仓未来采用一份根 `pnpm-lock.yaml` 和 pnpm workspace；Java 不增加根聚合 Module 或多个业务 Maven Module。版本/配置文件将在 P02 创建。

## 后端包边界

基础包暂定 `com.company.scaffold`；生成工具须替换基础包及源码路径，不让业务实现依赖固定公司名称。

| 模块 | 责任 |
| --- | --- |
| shared | 跨模块技术能力和稳定契约，禁止成为业务大杂烩 |
| platform | 平台管理通道与平台管理员能力 |
| identity | 租户员工身份、权限、角色和组织关系 |
| customeridentity | 客户独立认证域与微信身份映射 |
| attachment | 附件元数据、授权访问和本地存储生命周期 |
| audit | 审计记录与查询边界 |
| notification | 通知模型、渠道适配和可选消息投递 |
| modules | 新项目的业务模块扩展点；模板自身不含行业业务 |

shared 规划 api、exception、config、security、tenancy、persistence、redis、messaging、storage、wechat、observability。

每个有实际行为的业务模块采用：api（协议与控制器）、application（用例、事务与协调）、domain（业务规则）、infrastructure（持久化与外部适配）。依赖从 api 到 application；domain 不依赖控制器、请求上下文或微信 SDK；infrastructure 实现需要的端口。不得为了层级完整创建无行为接口或 Wrapper。

跨模块调用通过明确应用服务/端口与稳定 DTO；不直接访问其他模块 Repository 或泄露 Entity。具体依赖图、事务和模块测试在 P01-02 冻结。

## 三端责任

Web 保存应用壳、路由、会话、权限呈现、请求层和页面模式；小程序保留原生页面结构、会话域和请求实现。两端只共享协议类型，不共享 UI、状态、Cookie/Token 持久化和运行时网络实现。

infra/local 的 RabbitMQ 未来采用可选 profile，关闭时后端无消息连接要求。模板与 scripts 面向生成的新项目，原项目配置和 secrets 不进入模板。

## 当前实际结构

实际文件列表由 [验证报告](../testing/P01-01-VERIFICATION.md) 记录。探针工程位于系统临时目录；归档探针是测试证据，不是 `apps/` 的正式工程，不可作为已完成 P02 的依据。
''',
'docs/contracts/CORE-CONTRACTS.md':'''# 核心契约概要

日期：2026-10-07。当前记录方向与约束；详细路径、错误注册表、OpenAPI schema、认证端点和三端传输契约在 P01-02 冻结。以下 JSON 仅为协议形状，不是 Mock 业务验收。

## 统一响应和错误

成功：
```json
{ "success": true, "data": {}, "traceId": "..." }
```

失败：
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "请检查填写内容",
    "fieldErrors": []
  },
  "traceId": "..."
}
```

HTTP 状态码表达实际结果，不一律返回 200：400 输入错误、401 未认证、403 无权、404 不存在、409 冲突、500 内部错误的详细映射后续冻结。错误代码稳定、文案中文；内部异常、SQL、物理路径、凭证不返回客户端。traceId 是可关联诊断的服务端标识，不是授权信息。下载和微信回调遵守各自协议，不套统一 JSON。

fieldErrors 可选，支持嵌套字段和数组。P01-02 确定字段路径表示法、字段错误元素结构、空 data/204 语义、traceId 头及错误注册方式，当前不将这些未细化字段冒充已冻结接口。

## 分页和排序

page 从 1 开始，默认 pageSize=20，最大 100；返回 items、page、pageSize、total。后端映射到 JPA 的零基页号；非法页号或超限策略后续明确，不做静默行为猜测。排序仅允许服务端白名单，禁止直接将客户端字段拼接到 SQL；追加稳定唯一条件使分页可重复。

## 类型和时间

| 类型 | 协议约束 |
| --- | --- |
| ID | 字符串，避免 JavaScript 整数精度丢失 |
| 金额 | 十进制字符串，服务端采用精确十进制；币种、精度和舍入后续冻结 |
| 时间点 | 带时区，响应统一 UTC；不把无时区本地时间当成时间点 |
| 纯日期 | YYYY-MM-DD，无时区换算 |
| 枚举 | 稳定代码，不以中文显示文本作协议值 |
| 日期区间 | 开始包含、结束不包含；按业务时区解释纯日期边界后再转换 |

OpenAPI 是接口协议事实源。Web 与小程序复用生成类型，分别使用 fetch 与 wx.request；生成类型不保证运行时 JSON 校验、金额/日期转换或授权正确。不得手工改生成类型来掩盖服务端协议不一致。

## 认证方向及可行性

Sa-Token 服务端会话；通过不同 StpLogic loginType、Token/Cookie 名称、读取策略和存储键隔离平台管理员、租户员工、客户，不能仅给 loginId 加前缀。Web 默认同源 HTTPS Cookie，HttpOnly、Secure、受控 Path/Domain 和 SameSite 为组合属性；小程序采用独立 Token，不额外建立 JWT 刷新体系。

Cookie 写请求另设 CSRF 防护：会话绑定的不可预测令牌及请求头验证、Origin/Referer 校验和明确安全方法边界；SameSite 只是补充。登录、退出、失效、会话轮换与 CSRF 令牌更新须共同设计。详细令牌传递和有效期在 P01-02 冻结，P05 用真实浏览器请求验证；当前没有实现防护。

跨源 Web 部署作为可选方案，需要受限 CORS origin、凭证设置、Cookie 属性、CSRF 与浏览器第三方 Cookie 条件联合验证；不使用携带凭证的通配来源。

Sa-Token 多账号机制与 Cookie 配置依据：[多账号认证](https://sa-token.com/up/many-account.html)、[框架配置](https://sa-token.com/use/config.html)。当前可行性验证范围见 [报告](../testing/P01-01-VERIFICATION.md)。

## 租户和数据范围

单租户、多租户共用隔离机制；tenantId 从可信身份及已授权租户选择获得，不信任请求体或请求头自报值。Store 为可选经营门店，Organization 为内部组织，Tenant 为隔离边界；三者分别建模。

数据范围支持租户、授权门店、本人。查询与写入必须同时执行隔离；无上下文默认拒绝。附件、导出、缓存键、消息、后台任务和线程间传播同样受限；异步完成后清理上下文，避免跨请求泄漏。平台管理显式授权，不允许通过空 tenantId 自动变成全局查询。

P01-02 详细冻结执行位置、Repository/原生 SQL/批量写防护、消息上下文格式、系统任务与平台管理例外和验证矩阵。本轮未实现 tenant 过滤器或权限功能。
''',
'docs/development/ROADMAP.md':'''# 开发路线图

日期：2026-10-07。阶段编号是本项目工程路线，不是治理框架状态；不建立审批工作流。当前只执行 P01-01，后续均未开始。

| 阶段 | 目标与任务 | 前置依赖 | 交付物 | 完成条件 | 验证方式 | 当前状态 |
| --- | --- | --- | --- | --- | --- | --- |
| P01 技术基线与工程规范 | P01-01 事实/版本/基线；P01-02 架构与三端契约详细冻结 | 独立目录、明确固定技术方向 | 规则、矩阵、结构、契约、路线及架构详细决策 | P01-01 条件满足且详细契约可供三端初始化实施 | 官方来源、临时解析/编译探针、文档引用检查 | IN_PROGRESS；P01-02 NOT_STARTED |
| P02 三端工程初始化 | 唯一后端 Module/Wrapper；React workspace；原生小程序；本地依赖和开关 | P01 完成及对应任务授权 | 三端工程、锁文件、配置样例、基础启动说明 | 三端可独立构建；可选能力关闭可启动；无行业业务 | Wrapper 构建、frozen install、tsc/Vite、小程序构建、启动检查 | NOT_STARTED |
| P03 后端协议与数据基础 | 统一响应/错误/分页/序列化；OpenAPI；JPA/Flyway/事务 | P02 | 协议基础、迁移和生成类型流程 | 协议与生成类型一致；真实 PostgreSQL 迁移和事务可重复 | JUnit、Testcontainers PostgreSQL、OpenAPI 生成与类型编译 | NOT_STARTED |
| P04 多租户与数据范围 | 可信 TenantContext；租户/门店/本人范围；查询和写入隔离；异步传播 | P03 | 租户策略、持久化防护与范围测试 | 单/多租户共用机制；无上下文拒绝；越权查询和写入被阻止 | 真实 PostgreSQL 的跨租户读写/批量/原生 SQL 反向测试 | NOT_STARTED |
| P05 认证与身份权限 | Sa-Token Redis 会话；平台/员工/客户隔离；角色权限；Cookie/CSRF | P04 | 身份模块、会话契约、权限与安全测试 | 会话失效真实生效；身份跨域拒绝；CSRF 正反例通过 | 真实 Redis、HTTP/Cookie/Token、CSRF、权限集成测试 | NOT_STARTED |
| P06 Web 应用基础 | 应用壳；TanStack Router/Query；fetch；会话/权限呈现；表单错误 | P03、P05 | Web 应用壳与请求/会话基础 | 同源会话与后端真实联通；错误/加载/空态清楚 | tsc、lint、build、真实后端联调与浏览器测试 | NOT_STARTED |
| P07 企业级页面与员工管理 | 官方组件列表/筛选/分页/详情/表单；员工/组织/角色页面 | P04～P06 | 页面模式与基础员工管理 | 服务端授权与数据范围实际生效；创建/修改/停用可验收 | 真实业务基础 API、权限反例、页面可访问性和端到端测试 | NOT_STARTED |
| P08 文件附件与审计 | 本地存储；附件授权/生命周期；导出；审计链 | P03～P05 | 附件和审计模块、Web 接入 | 跨租户访问拒绝；日志不泄露秘密；错误路径可恢复 | 文件/DB 集成、越权下载、生命周期和审计关联检查 | NOT_STARTED |
| P09 微信小程序基础 | 原生请求；类型；客户/员工域；页面模式；运行配置 | P03、P05 | 小程序应用基础及页面模式 | 真实后端联通；身份切换不混用；类型和 npm 构建可重复 | DevTools 编译、真机预览、真实 Token/网络/失效测试 | NOT_STARTED |
| P10 可选消息与微信能力 | RabbitMQ 开关、投递/幂等/重试；WxJava 按需接入 | P05、P08、P09；实际启用时复核维护窗口及外部配置 | 可选适配器、开关说明、验证报告 | 关闭无连接要求；启用场景真实通过；回调授权/验签符合协议 | 真实 RabbitMQ/Testcontainers；有配置的微信环境/回调联调 | NOT_STARTED |
| P11 工程初始化与代码模板 | project/package 替换；功能裁剪；后端/Web/小程序模板；开发说明 | P02～P10 所选范围稳定 | 初始化工具、三端模板、说明 | 不带秘密和行业业务；替换完整；重复使用不破坏现有目录 | 生成到全新临时目录，查残留标识，三端构建与真实基础设施检查 | NOT_STARTED |
| P12 全新项目验收与发布 | 全新生成项目验收；可选组合；版本复核；发布材料 | P11；对应发布授权 | 可复现模板包、验收证据和发布说明 | 全新项目能直接开发业务；启用/禁用组合通过；发布动作实际获授权 | 干净环境生成、真实端到端、安全反例、构建产物完整性 | NOT_STARTED |

## 当前任务与下一任务

P01-01：只检查事实、确定并验证版本、建立当前文档。最终状态以 [验证报告](../testing/P01-01-VERIFICATION.md) 为准。即使 COMPLETE，P01 仍是 IN_PROGRESS。

下一任务暂定 P01-02：核心架构与三端契约详细冻结。前置：P01-01 无影响后续的版本冲突、报告及矩阵可追踪、用户明确启动该任务；本轮不执行。

P01-02 需补齐模块依赖/事务、协议 schema/错误表/字段路径、认证空间/Cookie/CSRF/跨源、小程序请求、租户所有执行路径、金额/日期规则和后续测试边界。P02 只在 P01 完成并有对应任务授权时启动。

真实微信预览、支付、上传/发布所需外部凭证在相关任务中处理，当前不是 P01-01 必填材料；不得用占位配置声称真实验证通过。
''',
'docs/development/DECISION-LOG.md':'''# 工程决策记录

日期：2026-10-07。决定来自本次明确需求及官方/实际验证，不继承其他项目的版本或状态。这里只记录工程决定，不创建审批工作流。

| 编号 | 已确定决定 | 理由与证据 | 适用限制/后续事项 |
| --- | --- | --- | --- |
| D01 | 独立目录 enterprise-app-scaffold | 原目录有 UI 成果；用户明确选择同级新目录 | 不覆盖、不复制原行业业务；不初始化 Git/正式应用 |
| D02 | Java 21 LTS / Temurin | 长期维护、生态兼容；官方支持页与实际临时工具链 | 安全补丁复核，不将本机旧 JDK 当目标发行版 |
| D03 | Spring Boot 4.0 + Sa-Token Boot 4 + springdoc 3.0 | 官方匹配关系；Maven 和运行探针 | 使用精确矩阵，不选择不匹配的 Boot 3 starter 或 springdoc 2 |
| D04 | 一个 Maven Module 的模块化单体，Maven Wrapper only-script | 固定需求；官方 Wrapper；实际分发下载与构建 | 系统 Maven 仅用于本次临时引导；后续开发/CI 使用 Wrapper |
| D05 | PostgreSQL / Flyway PostgreSQL 模块 / Boot BOM | 官方数据库支持方式和真实依赖树 | DB 运行和迁移在 P03 真正验证，不用 H2 替代 |
| D06 | WxJava 原始 miniapp/pay 模块可选；Hutool 仅 core | 避免 SDK starter 重新引入框架版本及工具范围扩张 | 依赖并存不代表微信 API/支付真实可用 |
| D07 | Node.js 24 LTS、pnpm 10、Vite 7.3/React 插件 5 | Node 维护期、Vite 支持线和 npm engine/peer；隔离工具链 | 不改变全局 Node/pnpm；Vite/插件按组合升级 |
| D08 | React/DOM 同版本、Ant Design 6 | 官方 React 19 支持条件，不额外加入 v5 补丁 | 支持现代浏览器，浏览器实测在后续任务 |
| D09 | TypeScript 5.9、ESLint 10、Vitest 4 | TS 7 不满足 openapi-typescript/静态工具 peer；ESLint 9 已 EOL | 所有直接工具依赖精确；不加入无需求的大量工具 |
| D10 | pnpm 单 workspace/单锁文件、原生小程序 | 固定需求；离线 npm 打包验证布局 | 不引入第二包管理器；DevTools/真机仍需独立验证 |
| D11 | OpenAPI 为事实源，生成纯类型；请求实现分端 | 固定协议方向和实际生成探针 | 类型生成不替代运行时校验/权限验证 |
| D12 | 服务端会话、三类身份空间、安全 Cookie + 独立 CSRF | Sa-Token 官方多账号/配置可行性 | 有效期、轮换、CSRF 细节在 P01-02，真实防护在 P05 |
| D13 | 可信 tenantId，默认拒绝，单/多租户共用隔离 | 固定需求，涵盖数据和非 DB 资源 | P01-02 详细冻结，P04 起真实越权读写验收 |
| D14 | Redis 8.2 Extended，RabbitMQ 4.3 可选 | 官方支持策略及发行信息 | RabbitMQ 2026-11-30 前后复核；Redis 分发许可单独检查 |
| D15 | 当前只执行 P01-01，P01-02 为下一任务 | 用户明确范围 | 无自动阶段推进，无提交/推送/部署，无 Product Delivery OS |

## 尚未细化（不作为已完成实现）

P01-02：模块依赖/端口和事务；OpenAPI schema、HTTP 错误表、fieldErrors 路径；ID 生成算法、金额精度/币种/舍入；时间输入与区间转换；租户执行位置、系统任务、平台管理例外；身份 Token 名称/读取策略/有效期、Cookie 和 CSRF 传递；跨源部署条件；Web 代码路由或官方文件路由插件；小程序目标基础库及开发工具版本；本地存储生命周期和测试边界。

P02 及后续：正式锁文件/Wrapper 分发校验、配置样例、基础设施 digest；真实 PostgreSQL/Redis/RabbitMQ/浏览器/微信场景；是否启用可选能力。所有当前未运行场景在 [报告](../testing/P01-01-VERIFICATION.md) 如实列为 NOT_EXECUTED/NOT_VERIFIED。

## 研究中排除的组合

不采用 Vite 7 配 React 插件 6（插件 6 的 peer 要求 Vite 8）；不采用 TypeScript 7 配当前 OpenAPI 类型生成器（peer 为 TypeScript 5）；不采用已停止维护的 ESLint 9；不使用 React 19 + Ant Design 5 的补丁路径作为新模板默认。
'''
}
for name,text in files.items():
 path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
print('CREATED',len(files),'documents',root)
