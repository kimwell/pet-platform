from pathlib import Path
import json,re
root=Path('/Users/kimwell/work/enterprise-app-scaffold');temp=Path(Path('/tmp/enterprise-scaffold-p01-current-path.txt').read_text());p=temp/'research';ev=temp/'evidence';v=json.loads((p/'selected-npm.json').read_text());date='2026-10-07';R='DOCUMENTED / RESOLVED';C=R+' / COMPILED';RT=C+' / RUNTIME_VERIFIED'
rows=[]
def add(group,name,use,version,source,req,basis,levels,limit):rows.append(dict(group=group,component=name,purpose=use,version=version,source=source,query_date=date,requirements=req,compatibility=basis,levels=levels,limitations=limit))
bom='https://repo.maven.apache.org/maven2/org/springframework/boot/spring-boot-dependencies/4.0.8/spring-boot-dependencies-4.0.8.pom'
add('后端','Java / Eclipse Temurin','编译和运行','21.0.12.1+1（目标 release=21）','https://github.com/adoptium/temurin21-binaries/releases/tag/jdk-21.0.12.1%2B1','本次 macOS arm64；其他 OS 使用同发行版对应资产','Java 21 LTS 维护至少至 2029-12；Boot 4.0 支持 Java 17～26',RT,'验证是 macOS arm64；Linux/Windows 未运行')
add('后端','Maven Wrapper','项目工具链','3.3.4 / only-script','https://maven.apache.org/tools/wrapper/maven-wrapper-plugin/wrapper-mojo.html','JDK、POSIX shell 或 Windows cmd；首次下载网络','官方轻量脚本下载固定 Maven；本次实际引导并调用 Wrapper',R+' / RUNTIME_VERIFIED','Windows mvnw.cmd 未运行；系统 Maven 仅用于临时引导')
add('后端','Apache Maven','构建','3.9.16','https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/3.9.16/','Boot 要求 Maven ≥3.6.3','Wrapper 固定精确分发地址、SHA-256；实际 Maven 3.9.16 运行',R+' / RUNTIME_VERIFIED','首次下载网络依赖；不要求全局 Maven')
add('后端','Spring Boot','框架','4.0.8','https://docs.spring.io/spring-boot/4.0/system-requirements.html','Java ≥17，Maven ≥3.6.3','Boot 4.0 / Sa-Token Boot4 / springdoc3.0 对齐；JVM 上下文与 MockMvc 实际通过',RT,'未创建正式服务，未启动 TCP 端口；不代表三端/生产验收')
for name,use,version,req,basis,level,limit in [
 ('Spring Framework','Spring 基础','7.0.9','Java ≥17','Boot BOM 实际解析',RT,'仅本轮 JVM 场景'),
 ('Spring Data BOM','依赖对齐','2025.1.7','Spring Boot 4.0','Boot BOM 实际解析',R,'不手动覆盖子项目版本'),
 ('Spring Data JPA','持久化','4.0.7','Java 21 / PostgreSQL','Boot BOM 实际依赖树',R,'本轮无 Entity/Repository/DB 运行验证'),
 ('Hibernate ORM','JPA 实现','7.2.24.Final','Java 21 / Jakarta Persistence','Boot BOM 实际依赖树',R,'无真实 PostgreSQL ORM/事务/锁测试'),
 ('Spring Data Redis','Redis 访问','4.0.7','Redis 服务用于真实操作','Boot BOM；自动配置上下文创建成功',R,'未连接真实 Redis'),
 ('Lettuce','Redis 驱动','6.8.2.RELEASE','Java 21 / Redis','Boot BOM 实际解析；Bean 初始化',R,'macOS native DNS provider 缺失警告，使用系统回退；未验证 DNS/Redis I/O'),
 ('Spring AMQP / spring-rabbit','可选消息','4.0.5','真实消息场景需要 RabbitMQ','Boot BOM 实际解析',R,'未运行消息/重试/确认'),
 ('RabbitMQ Java Client','AMQP 驱动','5.27.1','RabbitMQ 4.3，AMQP 0-9-1','Boot BOM 实际解析',R,'无真实连接'),
 ('Flyway Core + PostgreSQL 模块','迁移','11.14.1 / 11.14.1','同时引入 flyway-database-postgresql','Boot BOM 实际解析；Flyway 配置加载通过',C,'未执行 PostgreSQL 迁移；不能以 load() 当 DB 验收'),
 ('PostgreSQL JDBC','数据库驱动','42.7.13','PostgreSQL 17','Boot BOM 实际解析',R,'未真实连接数据库'),
 ('Jackson 3 / Jackson 2','框架及 SDK JSON','3.1.5 / 2.21.5','tools.jackson / com.fasterxml.jackson 不同包名','Boot BOM 分别管理两套 BOM；共存依赖树与 OpenAPI 运行通过',R,'WxJava 全部 JSON/支付调用未验证，不强制替换 SDK JSON 栈'),
 ('JUnit Jupiter','Java 测试','6.0.3','Java ≥17','Boot BOM；3 项真实探针运行',RT,'不把这些技术探针当完整业务验收'),
 ('Testcontainers','数据库集成测试框架','2.0.5','真实容器测试需要 Docker','Boot BOM；使用 testcontainers-postgresql / testcontainers-junit-jupiter 的 2.x 模块名',C,'仅构造 PostgreSQLContainer；未启动容器'),
 ('Mockito','Boot 测试传递依赖','5.20.0','Java 21','Boot BOM，测试运行实际加载',R+' / RUNTIME_VERIFIED','动态 agent 自附加警告；P02 测试配置应显式处理'),
 ('Maven Compiler Plugin','Java 编译','3.14.1','目标 release 21','Boot parent 实际有效 POM；testCompile 成功',R+' / RUNTIME_VERIFIED','本轮编译的是测试探针'),
 ('Maven Surefire Plugin','JUnit 执行','3.5.6','JUnit 6.0.3','Boot parent 实际有效 POM；3 tests, 0 skipped',R+' / RUNTIME_VERIFIED','完整业务测试尚未实现')]:add('后端',name,use,version,bom,req,basis,level,limit)
for name,use,version,path,basis,level,limit in [
 ('Sa-Token Boot4 starter + Redis template','认证会话','1.46.0 / 1.46.0','cn/dev33/sa-token-spring-boot4-starter/1.46.0','官方 Boot4 starter；包含 sa-token-jackson3；同版本 Redis 模块；上下文与内存多身份会话测试',RT,'Redis 会话持久性、Cookie/CSRF/完整权限未实现或运行'),
 ('Hutool Core','受限工具','5.8.47','cn/hutool/hutool-core/5.8.47','仅 core；实际解析、编译和字符串工具调用',RT,'不引入 all；不替代安全/存储/协议实现'),
 ('WxJava 小程序模块','可选微信接口','4.8.0','com/github/binarywang/weixin-java-miniapp/4.8.0','官方正式发行；原始模块；依赖树与 WxMaServiceImpl 构造通过',RT,'RUNTIME_VERIFIED 仅 SDK 基础加载；无真实微信请求'),
 ('WxJava 支付模块','可选支付适配','4.8.0','com/github/binarywang/weixin-java-pay/4.8.0','与 miniapp 同版本；原始模块；WxPayServiceImpl 构造通过',RT,'仅基础加载；无商户配置、验签、回调或支付验收'),
 ('springdoc WebMVC UI','OpenAPI','3.0.3','org/springdoc/springdoc-openapi-starter-webmvc-ui/3.0.3','官方 Boot4.0→springdoc3.0 矩阵；实际 /v3/api-docs 返回通过',RT,'本轮 MockMvc 技术探针；公开策略在后续明确')]:add('后端',name,use,version,'https://repo.maven.apache.org/maven2/'+path+'/', 'Java 21 / Spring Boot 4.0.8',basis,level,limit)
add('前端','Node.js','前端工具链','24.21.0','https://nodejs.org/dist/v24.21.0/','本次 macOS arm64；LTS 至 2028-04-30','Vite/插件要求 ^20.19.0 或 ≥22.12.0；实际隔离 Node 运行',R+' / RUNTIME_VERIFIED','本机默认仍为 22.23.2；其他 OS 未执行')
uses={'pnpm':'唯一前端包管理器','react':'UI 运行时','react-dom':'DOM/SSR 运行时','typescript':'三端类型检查','vite':'Web 构建','@vitejs/plugin-react':'React 编译/HMR','antd':'官方 Web 组件/表单','@ant-design/icons':'官方图标','@tanstack/react-router':'唯一路由','@tanstack/react-query':'服务端状态','zustand':'轻量客户端状态','@types/react':'React 类型','@types/react-dom':'React DOM 类型','@types/node':'Node 类型','eslint':'静态检查','@eslint/js':'基础 ESLint 规则','typescript-eslint':'TypeScript ESLint','eslint-plugin-react-hooks':'Hooks 规则','eslint-plugin-react-refresh':'Refresh 规则','vitest':'前端测试','openapi-typescript':'OpenAPI 生成类型','tdesign-miniprogram':'官方小程序组件','miniprogram-api-typings':'原生微信 API 类型','miniprogram-ci':'可选独立微信检查/构建工具'}
metadata=[]
for name,version in v.items():
 if name not in uses:continue
 d=json.loads((p/('npm-'+name.replace('/','_')+'.json')).read_text());m=d['versions'][version];req=str(m.get('engines',{})).replace('|','或');peers=str(m.get('peerDependencies',{})).replace('|','或');limit='当前只验证技术探针';level=RT
 if name in ['@types/react','@types/react-dom','@types/node','miniprogram-api-typings']:level=C;limit='类型通过不代表对应设备/浏览器运行'
 if name=='antd':limit='源码 strict=true/skipLibCheck=true；完整第三方声明检查 FAIL；SSR Form/Button 通过，其他 UI 与浏览器未验收'
 if name=='tdesign-miniprogram':level=C;limit='源码 strict=true/skipLibCheck=true；SDK 声明全面检查 FAIL；实际 npm 组件输出通过，DevTools/真机未运行'
 if name=='typescript':limit='源码 strict=true；第三方声明采用 skipLibCheck；不宣称 vendor d.ts 全面通过'
 if name=='miniprogram-ci':level=R+' / RUNTIME_VERIFIED';limit='仅独立 pnpm dlx 工具；未加入主 workspace；内部 parser 依赖 ESLint7/8，本次隔离解析 ESLint8.57.1（EOL）；仅离线 pack API 验证，未预览/上传'
 if name=='@vitejs/plugin-react':limit='固定 5.2.0，支持 Vite7；不使用要求 Vite8 的 6 系列'
 if name=='openapi-typescript':limit='peer TypeScript5；本轮中性契约生成与编译，无正式业务契约'
 group='小程序与契约工具' if name in ['tdesign-miniprogram','miniprogram-api-typings','miniprogram-ci','openapi-typescript'] else '前端'
 source='https://registry.npmjs.org/'+name.replace('/','%2f')+'/'+version
 add(group,name,uses[name],version,source,req if req!='{}' else '按 Node 24 / TypeScript 5.9 工具链', '官方注册信息 peer '+peers+'；实际安装/对应探针',level,limit)
 metadata.append({'name':name,'version':version,'query_date':date,'published':d.get('time',{}).get(version),'engines':m.get('engines'),'peerDependencies':m.get('peerDependencies'),'peerDependenciesMeta':m.get('peerDependenciesMeta'),'deprecated':m.get('deprecated'),'dist':m.get('dist'),'repository':m.get('repository'),'source':source})
for name,use,version,source,req,basis,limit in [
 ('PostgreSQL','数据库','17.11（postgres:17.11-bookworm）','https://www.postgresql.org/support/versioning/','本次官方 manifest 含 linux/arm64 和 amd64','17 系列维护至 2029-11-08；官方镜像 manifest 解析通过','数据库运行、Flyway 迁移、SQL/锁均 NOT_VERIFIED'),
 ('Redis Open Source','会话/缓存','8.2.10（redis:8.2.10-bookworm）','https://redis.io/docs/latest/operate/oss_and_stack/install/version-mgmt/','Docker 或对应官方二进制；Java客户端 Lettuce','8.2 Extended 维护至 2030-09-01；官方镜像 manifest 解析','实际 Redis I/O、会话持久性未运行；分发许可须按使用方式核对'),
 ('RabbitMQ','可选 AMQP','4.3.6（rabbitmq:4.3.6-management）','https://www.rabbitmq.com/release-information','采用官方镜像携带 Erlang，默认不启用','官方当前社区支持线，镜像 manifest 解析；协议 AMQP0-9-1','社区支持至 2026-11-30；P10 启用前复核；无真实消息运行')]:add('基础设施',name,use,version,source,req,basis,R,limit)
(ev/'selected-npm-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2));(ev/'version-records.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
lines=['# 精确技术版本矩阵','', '查询日期：2026-10-07（Asia/Shanghai）。这是项目版本的唯一文档事实源。BOM 管理项保留 BOM，不在正式 POM 中逐项重复覆盖；实际值来自 [依赖树](../testing/evidence/P01-01/backend-dependency-tree.txt) 与 [有效 POM](../testing/evidence/P01-01/backend-effective-pom.xml)。直接 npm 版本与 engine/peer/发布时间见 [官方包元数据快照](../testing/evidence/P01-01/selected-npm-metadata.json)。','', 'DOCUMENTED=官方资料确认；RESOLVED=实际依赖/分发/manifest 解析；COMPILED=实际类型/Java 编译或构建；RUNTIME_VERIFIED=指定探针场景实际运行；NOT_VERIFIED=该场景未验证。等级可以并列；SDK 构造、SSR、MockMvc、npm 打包均不替代真实外部服务/设备验收。','']
for group in ['后端','前端','小程序与契约工具','基础设施']:
 lines+=['## '+group,'','| 组件 / 用途 | 精确版本 | 来源 | 查询日期 | 运行要求 | 兼容依据 | 验证等级 | 已知限制 |','| --- | --- | --- | --- | --- | --- | --- | --- |']
 for r in rows:
  if r['group']==group:lines.append('| '+r['component']+' / '+r['purpose']+' | '+r['version']+' | [官方来源]('+r['source']+') | '+date+' | '+r['requirements']+' | '+r['compatibility']+' | '+r['levels']+' | '+r['limitations']+' |')
 lines+=['']
lines+=['## 特别兼容依据与边界','', '- [Spring Boot 4.0 要求](https://docs.spring.io/spring-boot/4.0/system-requirements.html)：Java 21 与 Maven 3.9 均满足。','- [springdoc 官方矩阵](https://springdoc.org/#what-is-the-compatibility-matrix-of-springdoc-openapi-with-spring-boot-)：Boot4.0 配 3.0；[Sa-Token 官方说明](https://sa-token.com/start/example.html)：Boot4 使用 boot4-starter。','- [Flyway PostgreSQL 模块](https://documentation.red-gate.com/flyway/reference/database-driver-reference/postgresql-database)：PostgreSQL 支持需要单独模块；本次 org.flywaydb 两模块都解析为 11.14.1。','- [Ant Design 6 兼容说明](https://ant.design/docs/react/migration-v6-cn/)：React ≥18、支持 React19、图标使用6；不加入 v5 React19补丁。','- [Vite 维护线](https://vite.dev/releases)、[Node.js 生命周期](https://github.com/nodejs/Release)：选 Vite7.3 与 Node24LTS，使用插件5，避开插件6对 Vite8 的要求。','- [ESLint 维护状态](https://eslint.org/version-support/)：ESLint9已于2026-08-06停止维护，采用10。','- [Vite 官方 TypeScript 模板](https://github.com/vitejs/vite/blob/main/packages/create-vite/template-react-ts/tsconfig.app.json)：采用 strict 应用源码检查与 skipLibCheck；本轮 Web/TDesign 全面声明检查失败保留，不宣称修复上游声明。','- [TDesign 官方说明](https://github.com/Tencent/tdesign-miniprogram/blob/develop/README.md)：组件 npm 构建与基础库最低条件；其历史最低基础库2.6.5不作为当前产品目标基础库承诺，P01-02冻结精确基础库/工具版本并在P09验证。','- [微信官方 CI](https://github.com/wechat-miniprogram/miniprogram-ci-dist)：packNpmManually 可在不提供 AppID/私钥的情况下离线构建。本轮主 workspace 不安装 CI；隔离工具仍含旧传递依赖，不能将它当成全仓 ESLint 工具。','', '官方镜像的精确多架构 digest 与平台清单见 [infra-images.json](../testing/evidence/P01-01/infra-images.json)。manifest 中 unknown/unknown 条目是附加描述，不能作为可运行平台；本轮没有拉取/启动镜像。','', 'Maven 编译/测试插件由 Boot parent 管理；Dependency Plugin 3.9.0 仅用于本轮依赖证据提取。Docker CLI/daemon/Compose 的本机版本见验证报告，不把本机版本等同于已冻结的生产容器环境。','', '基线可进入 P01-02 详细设计；它不代表第三方 SDK 全接口、真实基础设施、安全机制、浏览器或微信设备运行已经验证。']
(root/'docs/development/VERSION-MATRIX.md').write_text('\n'.join(lines)+'\n');print('MATRIX_ROWS',len(rows))
