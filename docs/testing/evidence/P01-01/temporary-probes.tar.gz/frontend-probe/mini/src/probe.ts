import type { TdButtonProps } from 'tdesign-miniprogram/miniprogram_dist/button/type';
// 只检查原生小程序类型，不注册业务页面、不创建微信配置。
export const props: TdButtonProps = { theme: { type: String, value: 'primary' } };
export function requestTypeProbe() {
  return wx.request<{ success: boolean }>({ url: 'https://example.invalid/compatibility', success: response => { const ok: boolean = response.data.success; return ok; } });
}
