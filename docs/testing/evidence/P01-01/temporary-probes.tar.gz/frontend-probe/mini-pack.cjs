const ci = require('miniprogram-ci');
const path = require('node:path');
ci.packNpmManually({ packageJsonPath: path.join(__dirname, 'mini/package.json'), miniprogramNpmDistDir: path.join(__dirname, 'mini') }).then(result => { console.log(JSON.stringify(result)); }).catch(error => { console.error(error); process.exitCode = 1; });
