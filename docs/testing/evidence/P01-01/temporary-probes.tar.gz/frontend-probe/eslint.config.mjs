import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import hooks from 'eslint-plugin-react-hooks';
import refresh from 'eslint-plugin-react-refresh';
export default [ { ignores: ['**/dist/**', '**/miniprogram_npm/**', '**/node_modules/**'] }, js.configs.recommended, ...tseslint.configs.recommended, {
  files: ['**/*.ts', '**/*.tsx'], languageOptions: { globals: { document: 'readonly', fetch: 'readonly', wx: 'readonly' } },
  plugins: { 'react-hooks': hooks, 'react-refresh': refresh }, rules: { ...hooks.configs.recommended.rules, 'react-refresh/only-export-components': ['warn', { allowConstantExport: true }] }
} ];
