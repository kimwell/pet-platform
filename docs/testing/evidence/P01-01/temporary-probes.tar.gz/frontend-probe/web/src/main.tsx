import { createRoot } from 'react-dom/client';
import { ConfigProvider } from 'antd';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { createRootRoute, createRoute, createRouter, RouterProvider } from '@tanstack/react-router';
import { Probe } from './Probe';
const rootRoute = createRootRoute();
const route = createRoute({ getParentRoute: () => rootRoute, path: '/', component: Probe });
const router = createRouter({ routeTree: rootRoute.addChildren([route]) });
declare module '@tanstack/react-router' { interface Register { router: typeof router } }
createRoot(document.getElementById('root')!).render(<ConfigProvider><QueryClientProvider client={new QueryClient()}><RouterProvider router={router} /></QueryClientProvider></ConfigProvider>);
