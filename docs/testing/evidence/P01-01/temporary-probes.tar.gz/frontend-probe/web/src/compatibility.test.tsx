import { expect, test } from 'vitest';
import { renderToString } from 'react-dom/server';
import { Button, Form, Input } from 'antd';
import { QueryClient } from '@tanstack/react-query';
import { createRootRoute, createRoute, createRouter, createMemoryHistory } from '@tanstack/react-router';
import { createStore } from 'zustand/vanilla';
test('React 与 Ant Design Form 在同一运行时渲染', () => {
  const html = renderToString(<Form><Form.Item name="value"><Input /></Form.Item><Button>兼容性验证</Button></Form>);
  expect(html).toContain('兼容性验证'); expect(html).toContain('ant-form');
});
test('Router、Query 与 Zustand 的实际 API 可以运行', async () => {
  const root = createRootRoute(); const route = createRoute({ getParentRoute: () => root, path: '/' });
  const router = createRouter({ routeTree: root.addChildren([route]), history: createMemoryHistory({ initialEntries: ['/'] }) });
  await router.load(); expect(router.state.location.pathname).toBe('/');
  const query = new QueryClient(); expect(await query.fetchQuery({ queryKey: ['probe'], queryFn: () => 'ready' })).toBe('ready'); query.clear();
  const store = createStore<{ ready: boolean }>(() => ({ ready: false })); store.setState({ ready: true }); expect(store.getState().ready).toBe(true);
});
