import { Button, Form, Input } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { useQuery } from '@tanstack/react-query';
import { create } from 'zustand';
// 仅验证框架 API 与类型组合，无业务数据和真实请求。
const useProbe = create<{ ready: boolean }>(() => ({ ready: true }));
export function Probe() {
  const ready = useProbe(s => s.ready);
  useQuery({ queryKey: ['compatibility'], queryFn: async () => (await fetch('/compatibility')).text(), enabled: false });
  return <Form<{ value: string }>><Form.Item name="value"><Input /></Form.Item><Button disabled={!ready} icon={<CheckOutlined />}>兼容性验证</Button></Form>;
}
